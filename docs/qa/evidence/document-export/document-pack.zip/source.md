﻿# Tiếng Việt

**Đậm** và *nghiêng*.

- [x] Xong
- [ ] Chưa

| A | B |
|---|---|
| Một | Hai |

```dart
final x = 1;
```
